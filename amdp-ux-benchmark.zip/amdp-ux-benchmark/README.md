# AMDP UX benchmark: dashboard, data and prompts

Open this folder in VS Code, serve it, and plug in your data. The dashboard is the wheel from the workshop: click through platform, area, capability, stage and issue.

## Run it

1. Open the folder in VS Code (File, Open Folder).
2. Start a server. Any of these:
   - Terminal: `npm run serve` (needs Node 18 or newer), then open http://localhost:5173
   - Terminal: `python3 -m http.server 5173`, then open http://localhost:5173
   - VS Code: Run Task, "Serve dashboard"; or the Live Server extension, right-click `index.html`, Open with Live Server.
3. Do not open `index.html` by double-clicking. Browsers block loading the data files that way.

## What is real and what is sample

- Real, from your report: the portfolio score, five dimension scores, issue totals, screen reviews and the eight product scores you shared. The 60% confidence is your working estimate.
- Sample, written as placeholders: every other capability score, all confidence per capability, the issue counts on the wheel, and everything for Low-Code Builder (stages, persona scores, issues, quotes, Jira status, fixes). Rows with `real` = 0 in `data/wheel.json` show hatched on the wheel.
- The product-to-capability mapping in `data/products.json` is a guess. Check it.

## Plug in your data

You can edit the JSON directly, or work in a spreadsheet:

1. `npm run json2csv` writes `data/csv/*.csv`. Edit those in Excel or VS Code (the Rainbow CSV extension helps).
2. `npm run csv2json` turns them back into JSON.
3. `npm run validate` checks types, ranges and cross-references (for example, every issue's stage must exist for its capability).

Or let Claude Code do the ingesting: see Prompts below. The order is: crawl, diagnostics, research, Jira, triage, confidence, validate.

Add a journey for another capability: copy the headers from `inputs/templates/`, fill `stages`, `persona_scores` and `issues` for it, and use its wheel `id` in the `capability` column. A dot appears on the wheel for every capability with a journey. Capabilities that share a name (for example Connectors) must be referenced by id.

Real screenshots: save the image in `data/screens/`, set `screenshot` on the issue (path from the project root), and set `box_x`, `box_y`, `box_w`, `box_h` as percentages of the image, measured from the top left. The page draws the highlight and pin over the image instead of the sketch.

Target score: `app/config.js`, `target` (4.0 now).

## Prompts and Claude Code

`.claude/skills/` holds ten skills. In the Claude Code extension for VS Code (or the terminal), type `/` and pick one, for example `/ingest-crawl`. `CLAUDE.md` gives Claude the project rules every time. The same prompts are plain text in `prompts/`, so you can paste them into any chat. `prompts/00-ask-from-dashboard.md` has the lines the dashboard suggests at each layer.

If a skill does not appear after you add it, restart VS Code. Put raw evaluator exports in `inputs/` (for example `inputs/crawl/`, `inputs/diagnostics/`, `inputs/research/`, `inputs/jira/`). Those folders are in `.gitignore` because they may hold sensitive material.

## Folder map

| Path | What it is |
|---|---|
| `index.html`, `app/` | the dashboard (plain HTML, CSS and JavaScript, no build step) |
| `app/config.js` | dataset files, optional files, target score |
| `data/` | the data, as JSON and CSV |
| `schema/` | the data contract in words and as JSON Schemas |
| `scripts/` | validate, CSV conversion, schema generation |
| `inputs/` | raw exports go here; CSV templates for new rows |
| `prompts/`, `.claude/skills/` | the pipeline prompts |
| `.vscode/` | tasks, recommended extensions, schema mapping |

## Notes

- The dashboard needs no internet and no packages. `npm run serve` fetches the small `serve` package the first time only.
- This is a local copy of the hosted dashboard. Changes you make here do not update the hosted version.
- Check your firm's policy on where this data may be used before you point an AI coding assistant at internal data, and keep screenshots free of customer information.
