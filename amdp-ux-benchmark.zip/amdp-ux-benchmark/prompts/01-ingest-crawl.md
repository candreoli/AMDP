# ingest-crawl

Turn UX crawl agent reports into portfolio, product and capability scores

Convert the UX crawl agent's exports into the benchmark data.

Inputs
- inputs/crawl/: the agent's exports (portfolio summary, per-product tables, per-screen issue lists).
- inputs/mapping.csv: product,capability. The capability is a wheel id or a unique capability name from data/wheel.json.

Write
- data/portfolio.json: score, visual, ux, a11y, responsive, conformance (1 to 5, as the agent reports them), blockers, majors, raised, screens, products. Leave `confidence` as it is; that is a team estimate.
- data/products.json: name, score, screens, of_total (only when the agent reviewed a sample; otherwise blank), cap.
- data/wheel.json: for each capability that has a mapped product, update score, the five dimensions, blockers and majors, and set real to 1. A capability with several products takes the mean of their scores and dimensions and the sum of their blockers and majors. Leave every other row alone.

Rules
- Count only issues of severity Blocker or Major.
- Keep one decimal, and keep the agent's scale.
- If a product is not in the mapping, or maps to more than one capability, stop and ask me; list them.
- After writing, compare the wheel totals for blockers and majors with the portfolio totals and tell me the difference.

Follow the rules in CLAUDE.md. In short: never invent a number, label, ticket, quote or mapping; every value you write must trace to a file under inputs/ or to something I tell you in this chat. Where a value is missing, leave it out and list it. Keep real data and sample data apart (the `real` column in data/wheel.json). Only Blockers and Majors count. After any change to data/, run `npm run validate` and fix every error before you finish. End with a short summary: what you changed, what you could not fill, and what you assumed.
