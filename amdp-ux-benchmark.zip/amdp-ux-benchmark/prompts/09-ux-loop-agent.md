# ux-loop-agent

Run one pass of the UX loop on a capability: fix, validate, hand to a human

Run one pass of the UX loop for one capability in the product repo that is open in this workspace.

Setup: ask me for the capability, the target score (default is in app/config.js) and the repo or folder the code lives in, if they are not obvious.

Pass
1. Read data/issues.json for the capability. Pick only issues that are valid, path A, effort S, and either Raised or already filed by a human. These are agent-ready. List them and wait for my go-ahead.
2. For each approved issue, work on its own branch. Use the design system components named in the fix. Add or update tests. Do not change anything outside the issue's screen.
3. Open a pull request that links the Jira ticket and quotes the finding.
4. Re-run the UX crawl on the changed screens using the team's agent command (ask me for it). Record the before and after for the issue. Do not edit scores in data/ by hand; they only change when the evaluators re-run and I re-ingest them.
5. Ask for human review and sign-off. Never approve or merge your own work.

Stop conditions
- Do not mark the capability done on score alone. It is done only when the score has reached the target and the outcome check has passed: a people study or an expert review, recorded by a person. If the score rises without the issue count falling, or the rubric or evaluator configuration changed, stop and tell me.
- Path B issues are not fixed here. Write a rebuild brief instead: what exists, why fixing is not worth it (cite the signal), and what to build on.

Log each pass in inputs/loop-log.md: date, issues attempted, PRs, before and after, what is waiting for a person.

Follow the rules in CLAUDE.md. In short: never invent a number, label, ticket, quote or mapping; every value you write must trace to a file under inputs/ or to something I tell you in this chat. Where a value is missing, leave it out and list it. Keep real data and sample data apart (the `real` column in data/wheel.json). Only Blockers and Majors count. After any change to data/, run `npm run validate` and fix every error before you finish. End with a short summary: what you changed, what you could not fill, and what you assumed.
