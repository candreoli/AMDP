# ingest-research

Add research vault evidence and quotes to issues

Attach evidence from people studies to the issues for one capability.

Inputs
- inputs/research/: interview notes, usability test results, vault exports.
- data/issues.json rows for the capability.

Write (only to existing issue rows)
- people: set to 1 when at least one session supports the issue, else leave 0.
- quote: one verbatim sentence or two from a participant that supports the issue. No names, no job titles that identify a person, no paraphrase. Leave blank when there is no good quote.

Rules
- Never invent or tidy a quote. If a quote needs trimming, trim with an ellipsis and keep the words in order.
- Do not add new issues here. If research reveals something no issue covers, list it for me as a candidate.
- Report how many sessions you read and how many issues gained evidence.

Follow the rules in CLAUDE.md. In short: never invent a number, label, ticket, quote or mapping; every value you write must trace to a file under inputs/ or to something I tell you in this chat. Where a value is missing, leave it out and list it. Keep real data and sample data apart (the `real` column in data/wheel.json). Only Blockers and Majors count. After any change to data/, run `npm run validate` and fix every error before you finish. End with a short summary: what you changed, what you could not fill, and what you assumed.
