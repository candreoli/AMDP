# Prompts from the dashboard

The dashboard ends each layer with an "Ask Claude" line. These are the same prompts, ready to paste into a Claude chat or Claude Code. Replace the names in brackets.

## Platform
- Write the CIO narrative for where we are, using the benchmark scores
- Draft the methodology and confidence slide for the CIO

## Area
- Write the where-we-are narrative for [area] using its weakest capabilities

## Capability
- Show pain points and research vault quotes for the [capability] journey for [persona or all personas], starting where sentiment is lowest
- Turn the [capability] fixes into a 2027 plan: what agents take, what the team rebuilds, and target scores

## Stage
- Draft the fix plan for the [stage] stage of the [capability] journey

## Issue
- Draft the Jira ticket for [issue id], or check the matching ticket against the finding

Better still, use the skills in `.claude/skills/` (type `/` in Claude Code): they read your data files and write results back to them.
