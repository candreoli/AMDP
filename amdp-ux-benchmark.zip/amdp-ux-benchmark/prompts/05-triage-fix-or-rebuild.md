# triage-fix-or-rebuild

Decide fix current or start again, and size each fix

Triage the valid issues for one capability into the fix plan.

Inputs: data/issues.json rows for the capability (jira_status is not Not valid), plus anything in inputs/triage-notes.md.

Set for each issue
- path: A (fix the current build) or B (start again).
- effort: S, M or L.
- lever and quadrant, using the workshop decisions:
  - Quick win: deliver the design system and mandate it (lever Design system).
  - Big bets: interoperability between flows and products; ontology and terminology mapping; findability and navigation.
  - Fill-ins: not decided yet. Do not invent any. If an issue fits nowhere, use lever Targeted fixes and quadrant Fix in place.
  - Avoid, which are signals for Path B: iframes and deprecated design systems. Put the signal in the `signal` column (Iframe or Deprecated design system).
- lift: the expected rise in the capability score from fixing this issue, between 0 and 1. Use small values (0.05 to 0.3), say how you chose them, and make sure the sum for a capability does not promise more than the gap to the target in app/config.js.

Output
- Update data/issues.json.
- Write inputs/triage-notes.md: for each issue one line of reasoning, and the assumptions behind effort and lift.
- Say which issues you are least sure about, and what information would settle them.

Follow the rules in CLAUDE.md. In short: never invent a number, label, ticket, quote or mapping; every value you write must trace to a file under inputs/ or to something I tell you in this chat. Where a value is missing, leave it out and list it. Keep real data and sample data apart (the `real` column in data/wheel.json). Only Blockers and Majors count. After any change to data/, run `npm run validate` and fix every error before you finish. End with a short summary: what you changed, what you could not fill, and what you assumed.
