# cio-narrative

Write the CIO story from the data: where we are, trust, and the ask

Write the CIO narrative for the benchmark, using only numbers that appear in data/*.json.

Structure
1. Frame: what the wheel is (the whole ecosystem from data to AI, with governance and connectivity running through it) and how the scores are made (three evaluators: two agentic and one people-study).
2. Where we are: portfolio score, the five dimensions, blockers and majors, the spread between products, the weakest dimension, and what the spread implies (systemic versus one weak product).
3. Trust: confidence, screen coverage, which evaluators are loaded, and what is still sample data.
4. One worked example: pick the capability with the lowest score that has a journey loaded and walk from stage to issue.
5. The ask: the decisions you want from the CIO, drawn from the quick wins and big bets in data/issues.json.

Output
- A one-page narrative of about 300 words, then a slide-by-slide script with the numbers beside each slide.
- Put a list at the end of every number used and the file and row it came from.
- If any row has real set to 0, say so plainly in the trust section.

Follow the rules in CLAUDE.md. In short: never invent a number, label, ticket, quote or mapping; every value you write must trace to a file under inputs/ or to something I tell you in this chat. Where a value is missing, leave it out and list it. Keep real data and sample data apart (the `real` column in data/wheel.json). Only Blockers and Majors count. After any change to data/, run `npm run validate` and fix every error before you finish. End with a short summary: what you changed, what you could not fill, and what you assumed.
