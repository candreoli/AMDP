# jira-validate

Check each issue against Jira and set its status

Validate the Blocker and Major issues for one capability against Jira.

Inputs
- Use the Jira (Atlassian) connector if it is available in this session. Otherwise read inputs/jira/export.csv.
- data/issues.json rows for the capability.

For each issue, search Jira by title keywords, screen name, component and the capability, then set
- jira_status: Raised when an open or in-progress ticket matches; Not raised when none does; Not valid when the team closed a matching ticket as Won't Fix, Not a bug or Works as designed.
- ticket: the Jira key when Raised, blank otherwise.

Also write inputs/jira/new-tickets.md with a draft for each Not raised issue: title, description (use the finding), steps to reproduce, acceptance criteria (use the fix), severity, labels, and which screen to attach. Do not create tickets in Jira; I will.

Rules
- Quote the matching ticket's title next to each match in your summary so I can check it.
- If one ticket matches several issues, or one issue matches several tickets, list them and ask before choosing.
- List every Not valid issue with the reason, so the UX agents can be tuned.

Follow the rules in CLAUDE.md. In short: never invent a number, label, ticket, quote or mapping; every value you write must trace to a file under inputs/ or to something I tell you in this chat. Where a value is missing, leave it out and list it. Keep real data and sample data apart (the `real` column in data/wheel.json). Only Blockers and Majors count. After any change to data/, run `npm run validate` and fix every error before you finish. End with a short summary: what you changed, what you could not fill, and what you assumed.
