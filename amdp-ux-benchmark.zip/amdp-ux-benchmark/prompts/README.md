# Prompts

Run these in order when you plug in real data. Each is also a Claude Code skill in `.claude/skills/<name>/SKILL.md`, so you can type `/<name>` in Claude Code. If a skill does not show up, restart VS Code, or paste the text from the file here.

| Step | Prompt | Writes |
|---|---|---|
| 1 | 01-ingest-crawl | portfolio.json, products.json, wheel.json |
| 2 | 02-ingest-diagnostics | stages.json, persona_scores.json |
| 3 | 03-ingest-research | issues.json (people, quote) |
| 4 | 04-jira-validate | issues.json (jira_status, ticket), inputs/jira/new-tickets.md |
| 5 | 05-triage-fix-or-rebuild | issues.json (path, effort, lever, quadrant, lift, signal) |
| 6 | 06-score-confidence | wheel.json (confidence), schema/confidence-method.md |
| 7 | 07-validate-and-run | nothing; validates and serves |
| 8 | 08-add-capability-journey | scaffold for a new capability |
| 9 | 09-ux-loop-agent | PRs in your product repo, inputs/loop-log.md |
| 10 | 10-cio-narrative | a narrative and slide script |

`00-ask-from-dashboard.md` holds the lines the dashboard suggests at each layer.
