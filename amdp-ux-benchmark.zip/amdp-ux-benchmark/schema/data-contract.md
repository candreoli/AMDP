# Data contract

Seven files in `data/`. Scores run 1 to 5, confidence 0 to 100, flags are 0 or 1, blanks are empty strings. `scripts/spec.mjs` is the same contract in code; `npm run validate` enforces it.

A `capability` column holds a wheel `id`, or a unique capability name. If two capabilities share a name, use the id.

## portfolio.json: one row per headline number
| column | type | meaning |
|---|---|---|
| key | text | one of: score, confidence, blockers, majors, raised, screens, products, visual, ux, a11y, responsive, conformance |
| value | number | the figure. score and the five dimensions are 1 to 5; confidence is 0 to 100 (the team's working estimate); the rest are counts |
| label | text | optional description |

Source: UX crawl agent portfolio summary; confidence from the team.

## products.json: one row per product scored
| column | type | meaning |
|---|---|---|
| name | text | product name |
| score | number | overall score 1 to 5 |
| screens | number | screens reviewed |
| of_total | number or blank | total screens, only when the agent reviewed a sample |
| cap | text | capability this product maps to (id or unique name), blank if unmapped |

Source: UX crawl agent per-product table. The mapping comes from you.

## wheel.json: capabilities and rings
Domain rows are not stored; the page rolls capabilities up by `domain`.
| column | type | meaning |
|---|---|---|
| id | text | unique id |
| name | text | capability or ring name |
| type | cap or ring | rings are the cross-cutting circles (Governance, Connectivity); the first is drawn inner |
| domain | text | for caps, the domain it belongs to. Keep a domain's capabilities adjacent by `ord` |
| ord | number | position around the wheel, 0, 1, 2 ... for caps; blank for rings |
| score | number | overall 1 to 5 |
| visual, ux, a11y, responsive, conformance | number | dimension scores 1 to 5 |
| confidence | number | 0 to 100 for this capability |
| blockers, majors | number | counts of those severities |
| real | 0 or 1 | 1 only when scored from real evaluator output; 0 shows hatched as sample |

Source: UX crawl agent, rolled up by capability (see `/ingest-crawl`). Confidence: `/score-confidence`.

## stages.json: journey stages per capability
| column | type | meaning |
|---|---|---|
| capability | text | wheel id or unique name |
| stage | text | short stage name, unique within the capability. Row order is journey order |
| full | text | the stage as a sentence |
| screen | text | main screen name |
| layout | gallery, builder or dialog | which sketch to draw when there is no screenshot |
| pain | text | one plain sentence about what users hit |
| seam | 0 or 1 | 1 when the stage is a hand-off between products |

Source: diagnostics agent (journeys, service blueprints).

## persona_scores.json: score per persona and stage
| column | type | meaning |
|---|---|---|
| capability | text | as above |
| persona | text | same names across all capabilities |
| stage | text | must exist in stages.json for the capability |
| score | number | 1 to 5 |

Every persona must have a score for every stage of a capability. The "All personas" view and the journey average are computed by the page.

## issues.json: one row per Blocker or Major
| column | type | meaning |
|---|---|---|
| capability, id, stage | text | id is unique across the file; stage must exist for the capability |
| severity | Blocker or Major | |
| dimension | Visual, UX, A11y, Responsive or Conformance | |
| title, finding, fix | text | what, why it matters, and the recommended fix |
| region | text | sketch region when there is no screenshot: cards, canvas, palette, config, console or modal |
| personas | text | affected personas separated by "; " |
| crawl, diagnostics, people | 0 or 1 | which evaluators found it. Evidence and per-issue confidence are computed from these |
| jira_status | Raised, Not raised or Not valid | Not valid issues do not count toward fixes |
| ticket | text | Jira key when Raised |
| effort | S, M or L | |
| lever | text | for example Design system, Interoperability, Ontology and terminology, Findability and navigation, Targeted fixes |
| quadrant | Quick win, Big bet or Fix in place | |
| lift | number 0 to 1 | expected rise in the capability score if fixed |
| path | A or B | A fix current, B start again |
| signal | text | why B: for example Iframe or Deprecated design system |
| quote | text | verbatim, anonymous participant quote from the research vault |
| screenshot | text | path from the project root, for example data/screens/LCB-07.png |
| box_x, box_y, box_w, box_h | number or blank | highlight box as percent of the image, from the top left |

Computed by the page from these rows: Jira counts, Path A and B counts, agent-ready count (Path A, effort S), path to green by lever, stage lift.

## confidence_parts.json (optional)
| column | type | meaning |
|---|---|---|
| part | text | for example Screen coverage |
| points, max | number | points earned out of the maximum |
| to_lift | text | what would raise it |
