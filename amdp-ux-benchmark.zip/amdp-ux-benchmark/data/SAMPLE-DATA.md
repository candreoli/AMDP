# What in this folder is sample data

- portfolio.json, products.json: real figures from the benchmark report you shared. `confidence` (60) is the team's working estimate. The `cap` column in products.json is a draft mapping.
- wheel.json: rows with `real` = 1 take their score from a product's real score. All other values on every row, including each dimension split, confidence and the blockers and majors per capability, are sample values.
- stages.json, persona_scores.json, issues.json: all sample, written for the Low-Code Builder worked example. Quotes are placeholders. Jira tickets and statuses are made up.
- confidence_parts.json: a draft split of the 60 into four parts.

Replace these as you ingest real output, and set `real` to 1 on wheel rows you have scored.
