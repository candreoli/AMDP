# AMDP UX benchmark

A static dashboard that shows the experience benchmark for the AMDP product suite as one wheel you can peel layer by layer: platform, area, capability, stage, issue. Data lives in `data/*.json`. The page in `app/` only reads those files.

## The story the dashboard tells
1. Where we are: portfolio score (1 to 5), five dimensions, blockers and majors, products, domains.
2. Trust: confidence in the scores, three evaluators (UX crawl agent, diagnostics agent, people studies), screen coverage.
3. Journey: per capability and persona, score by stage, sentiment, pain points, hand-off seams.
4. Issue: annotated screen, evidence from each evaluator, Jira status, recommended fix.
5. Fix: Jira validation, fix current (Path A) or start again (Path B), path to green, the UX loop.

## Rules for every change
- Never invent a number, ticket, quote, mapping or score. Every value must come from a file under `inputs/` or from the user.
- Scores run 1 to 5 with one decimal. Confidence runs 0 to 100.
- Only Blockers and Majors count. Minors are out of scope.
- `real` in `data/wheel.json` is 1 only for rows scored from real evaluator output. Leave sample rows at 0 so the dashboard hatches them.
- Quotes are verbatim and anonymous.
- Jira: Raised, Not raised, or Not valid. Do not create tickets; draft them for a person.
- The score alone never closes a capability. Done means the target score is reached and a person has passed the outcome check.
- After any change to `data/`, run `npm run validate` and fix all errors.

## Files
- `index.html`, `app/` the dashboard. `app/config.js` points each dataset id at a file and sets the target score.
- `data/*.json` the data. `data/csv/*.csv` are spreadsheet copies; `npm run csv2json` and `npm run json2csv` convert between them.
- `schema/data-contract.md` explains every column. `scripts/spec.mjs` is the machine-readable contract.
- `inputs/` raw evaluator exports (not committed). `inputs/templates/` has CSV headers for new rows.
- `.claude/skills/` the pipeline prompts. `prompts/` holds the same text as plain files.

## Commands
- `npm run serve` serves the folder at http://localhost:5173
- `npm run validate` checks all data
- `npm run csv2json` / `npm run json2csv`
- `npm run schemas` regenerates the JSON Schemas VS Code uses

## Glossary
- Blocker, Major: the two severities in scope.
- Seam: a hand-off between products in a journey.
- Path A: fix the current build. Path B: start again (signals: iframes, deprecated design systems).
- Lever: the kind of fix. Quick win = deliver the design system and mandate it. Big bets = interoperability, ontology and terminology mapping, findability and navigation. Fill-ins are not decided yet.
- UX loop: set a target, agents fix, agents validate, a team signs off, repeat until the outcome check also passes.
