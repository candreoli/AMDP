# Inputs

Drop raw evaluator exports here. These folders are in .gitignore:

- `inputs/crawl/` UX crawl agent exports
- `inputs/diagnostics/` diagnostics agent exports
- `inputs/research/` research vault notes and test results
- `inputs/jira/` Jira export (`export.csv`) and the drafted `new-tickets.md`
- `inputs/mapping.csv` product to capability (header: `product,capability`)
- `inputs/rubric.md` how findings convert to a 1 to 5 score

`inputs/templates/` has the CSV headers for new stage, persona and issue rows.
