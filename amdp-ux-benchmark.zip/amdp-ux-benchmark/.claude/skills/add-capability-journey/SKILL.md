---
name: add-capability-journey
description: Add journey, persona and issue data for a new capability. Use when the user asks for this step of the UX benchmark data pipeline or types /add-capability-journey.
---

Set up everything the dashboard needs to show a journey for a capability that has none yet.

Do
1. Confirm the capability exists in data/wheel.json and note its id. If it has the same name as another capability, refer to it by id everywhere.
2. Copy the headers from inputs/templates/stages.csv, persona_scores.csv and issues.csv. Fill them in using the ingest-diagnostics, ingest-research, jira-validate and triage-fix-or-rebuild steps in that order, or tell me which source files you need before you start.
3. For any issue with a screenshot, save the image under data/screens/ and set screenshot to its path, then box_x, box_y, box_w and box_h as percentages of the image width and height, measured from the top left.
4. Run `npm run csv2json` if you worked in CSV, then `npm run validate`.

Rules: use the same persona names as the other capabilities. One row per persona and stage in persona_scores.csv, with no gaps.

Follow the rules in CLAUDE.md. In short: never invent a number, label, ticket, quote or mapping; every value you write must trace to a file under inputs/ or to something I tell you in this chat. Where a value is missing, leave it out and list it. Keep real data and sample data apart (the `real` column in data/wheel.json). Only Blockers and Majors count. After any change to data/, run `npm run validate` and fix every error before you finish. End with a short summary: what you changed, what you could not fill, and what you assumed.
