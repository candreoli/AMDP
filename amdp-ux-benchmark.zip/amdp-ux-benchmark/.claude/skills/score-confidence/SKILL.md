---
name: score-confidence
description: Work out confidence per capability and explain it. Use when the user asks for this step of the UX benchmark data pipeline or types /score-confidence.
---

Compute how far to trust the scores.

Inputs: data/wheel.json, data/products.json, data/issues.json, data/portfolio.json.

Do
- For each capability, set `confidence` (0 to 100) from four parts, each worth up to 25 points: screen coverage (reviewed screens over total screens), evaluator agreement (share of its issues seen by two or more evaluators), human validation (share of its issues with people evidence), method calibration (only if I give you repeat-run data, otherwise leave this part out and say so).
- Write the formula and the inputs you used to schema/confidence-method.md, so anyone can recompute it.
- Update data/confidence_parts.json for the portfolio only if I give you the portfolio split. Do not change the portfolio `confidence` value in data/portfolio.json; that is the team's own estimate. Tell me what the computed portfolio figure would be beside it.

Rules
- A capability with no evidence for a part scores 0 for that part, not a guess.
- Show me the three lowest-confidence capabilities and what would raise them fastest.

Follow the rules in CLAUDE.md. In short: never invent a number, label, ticket, quote or mapping; every value you write must trace to a file under inputs/ or to something I tell you in this chat. Where a value is missing, leave it out and list it. Keep real data and sample data apart (the `real` column in data/wheel.json). Only Blockers and Majors count. After any change to data/, run `npm run validate` and fix every error before you finish. End with a short summary: what you changed, what you could not fill, and what you assumed.
