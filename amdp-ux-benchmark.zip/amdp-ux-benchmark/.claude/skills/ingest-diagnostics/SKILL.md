---
name: ingest-diagnostics
description: Turn diagnostics agent output into journey stages and persona scores for one capability. Use when the user asks for this step of the UX benchmark data pipeline or types /ingest-diagnostics.
---

Build the journey data for one capability from the diagnostics agent's output.

Inputs
- inputs/diagnostics/: IA, personas and journeys, task flows, heuristics, content and terminology, accessibility, usability, UX metrics, service ecosystem, blueprints, service design.
- inputs/rubric.md if it exists: how findings convert to a 1 to 5 score. If it does not exist, ask me for the rubric before scoring.
- The capability to build: ask me if I have not named it. Use its id from data/wheel.json.

Write
- data/stages.json: one row per journey stage in order: capability, stage (a short verb such as Connect), full (a sentence), screen (the main screen name), layout (gallery, builder or dialog, whichever sketch fits best), pain (one plain sentence from the top finding), seam (1 when the stage hands off between products, else 0).
- data/persona_scores.json: one row for every persona and stage, score 1 to 5, with the capability column set. The matrix must be complete. If the diagnostics do not cover a persona or stage, do not guess: list the gaps and leave those rows out.

Rules
- Take stage names and order from the journey and service blueprint diagnostics, not from your own idea of the product.
- A seam is a hand-off the diagnostics call out between products or teams.
- Use the same persona names in every capability.

Follow the rules in CLAUDE.md. In short: never invent a number, label, ticket, quote or mapping; every value you write must trace to a file under inputs/ or to something I tell you in this chat. Where a value is missing, leave it out and list it. Keep real data and sample data apart (the `real` column in data/wheel.json). Only Blockers and Majors count. After any change to data/, run `npm run validate` and fix every error before you finish. End with a short summary: what you changed, what you could not fill, and what you assumed.
