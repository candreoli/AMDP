---
name: validate-and-run
description: Validate the data, fix errors and open the dashboard. Use when the user asks for this step of the UX benchmark data pipeline or types /validate-and-run.
---

Run `npm run validate`. Fix every error it reports in data/*.json (or tell me what you need from me). Explain each warning in plain words and say whether it matters.

Then start the dashboard with `npm run serve`, open http://localhost:5173, and tell me what the platform view shows: portfolio score, confidence, blockers and majors, and which capabilities have journeys loaded (a dot on the wheel).

If you changed any CSV in data/csv/, run `npm run csv2json` first. If you changed any JSON, run `npm run json2csv` last so the CSV copies stay in step.

Follow the rules in CLAUDE.md. In short: never invent a number, label, ticket, quote or mapping; every value you write must trace to a file under inputs/ or to something I tell you in this chat. Where a value is missing, leave it out and list it. Keep real data and sample data apart (the `real` column in data/wheel.json). Only Blockers and Majors count. After any change to data/, run `npm run validate` and fix every error before you finish. End with a short summary: what you changed, what you could not fill, and what you assumed.
