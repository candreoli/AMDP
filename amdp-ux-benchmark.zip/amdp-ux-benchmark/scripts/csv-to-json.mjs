// Edit data/csv/*.csv in Excel or VS Code, then run: npm run csv2json
import fs from 'node:fs';
import { SPEC, coerce } from './spec.mjs';
import { parseCSV } from './csv.mjs';
let n = 0;
for (const [name, spec] of Object.entries(SPEC)) {
  const file = `data/csv/${name}.csv`;
  if (!fs.existsSync(file)) { if (!spec.optional) console.warn(`skip ${name}: no ${file}`); continue; }
  const [head, ...rows] = parseCSV(fs.readFileSync(file, 'utf8'));
  const out = rows.map((r) => Object.fromEntries(head.map((h, i) => [h.trim(), coerce(spec, h.trim(), r[i])])));
  fs.writeFileSync(`data/${name}.json`, JSON.stringify(out, null, 2) + '\n');
  console.log(`data/${name}.json  ${out.length} rows`); n++;
}
console.log(n ? 'Done. Now run: npm run validate' : 'Nothing converted.');
