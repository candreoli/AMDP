// Checks every data file against the contract and its cross-references: npm run validate
import fs from 'node:fs';
import { SPEC } from './spec.mjs';
const win = {}; new Function('window', fs.readFileSync('app/config.js', 'utf8'))(win);
const CFG = win.APP_CONFIG;
const errors = [], warns = [];
const E = (m) => errors.push(m), Wn = (m) => warns.push(m);
const data = {};
for (const [name, spec] of Object.entries(SPEC)) {
  const file = CFG.datasets[name];
  if (!file || !fs.existsSync(file)) { (spec.optional ? Wn : E)(`${name}: file not found (${file || 'not in app/config.js'})`); data[name] = []; continue; }
  let rows; try { rows = JSON.parse(fs.readFileSync(file, 'utf8')); } catch (e) { E(`${file}: not valid JSON (${e.message})`); data[name] = []; continue; }
  if (!Array.isArray(rows)) { E(`${file}: must be an array of row objects`); data[name] = []; continue; }
  data[name] = rows;
  rows.forEach((r, i) => {
    const at = `${file} row ${i + 1}${r.id ? ' (' + r.id + ')' : r.name ? ' (' + r.name + ')' : ''}`;
    for (const k of Object.keys(r)) if (!(k in spec.cols)) Wn(`${at}: unknown column "${k}"`);
    for (const [col, c] of Object.entries(spec.cols)) {
      const v = r[col];
      if (v === undefined || v === '' || v === null) { if (c.req) E(`${at}: "${col}" is required`); continue; }
      if (c.t === 'str' && typeof v !== 'string') E(`${at}: "${col}" must be text`);
      if ((c.t === 'num' || c.t === 'numblank') && typeof v !== 'number') E(`${at}: "${col}" must be a number, got ${JSON.stringify(v)}`);
      if ((c.t === 'num' || c.t === 'numblank') && typeof v === 'number') { if (c.min != null && v < c.min) E(`${at}: "${col}" ${v} is below ${c.min}`); if (c.max != null && v > c.max) E(`${at}: "${col}" ${v} is above ${c.max}`); }
      if (c.t === 'flag' && v !== 0 && v !== 1) E(`${at}: "${col}" must be 0 or 1`);
      if (c.t === 'enum' && !c.values.includes(v)) E(`${at}: "${col}" must be one of ${c.values.join(' | ')}, got "${v}"`);
    }
  });
}
// portfolio keys
const pk = new Set(data.portfolio.map((r) => r.key));
SPEC.portfolio.keys.forEach((k) => { if (!pk.has(k)) E(`data/portfolio.json: missing key "${k}"`); });
// wheel
const caps = data.wheel.filter((r) => r.type === 'cap'), capNames = new Set(caps.map((c) => c.name));
// A capability reference may be a wheel id or a unique name. Two capabilities can share a name (for example Connectors); then use the id.
const resolveCap = (ref) => { const byId = caps.find((c) => String(c.id) === String(ref)); if (byId) return byId; const L = caps.filter((c) => c.name === ref); return L.length === 1 ? L[0] : null; };
const refProblem = (ref) => { if (resolveCap(ref)) return ''; return caps.filter((c) => c.name === ref).length > 1 ? `"${ref}" matches more than one capability; use its id from data/wheel.json` : `"${ref}" is not a capability in data/wheel.json`; };
const ids = new Set(); data.wheel.forEach((r) => { if (ids.has(r.id)) E(`data/wheel.json: duplicate id "${r.id}"`); ids.add(r.id); });
if (capNames.size !== caps.length) Wn('data/wheel.json: some capabilities share a name; refer to those by id in products, stages, persona_scores and issues');
caps.forEach((c) => { if (!c.domain) E(`data/wheel.json: capability "${c.name}" needs a domain`); });
const ords = caps.map((c) => c.ord).sort((a, b) => a - b); if (ords.some((o, i) => o !== i)) Wn('data/wheel.json: ord should run 0,1,2,... with no gaps, and caps in the same domain must be adjacent');
const doms = []; caps.slice().sort((a, b) => a.ord - b.ord).forEach((c) => { if (doms[doms.length - 1] !== c.domain) { if (doms.includes(c.domain)) E(`data/wheel.json: domain "${c.domain}" is split into two groups; keep its capabilities adjacent by ord`); doms.push(c.domain); } });
if (data.wheel.filter((r) => r.type === 'ring').length > 2) Wn('data/wheel.json: only the first two rings are drawn');
// reconcile totals
const sumB = data.wheel.reduce((a, r) => a + (r.blockers || 0), 0), sumM = data.wheel.reduce((a, r) => a + (r.majors || 0), 0);
const pv = Object.fromEntries(data.portfolio.map((r) => [r.key, r.value]));
if (sumB !== pv.blockers) Wn(`wheel blockers add up to ${sumB}, portfolio says ${pv.blockers}`);
if (sumM !== pv.majors) Wn(`wheel majors add up to ${sumM}, portfolio says ${pv.majors}`);
// products
data.products.forEach((p) => { if (p.cap && refProblem(p.cap)) E(`data/products.json: product "${p.name}": ${refProblem(p.cap)}`); if (p.of_total !== '' && p.of_total != null && p.screens > p.of_total) E(`data/products.json: "${p.name}" reviewed more screens than it has`); });
if (data.products.length && data.products.length !== pv.products) Wn(`data/products.json has ${data.products.length} products, portfolio says ${pv.products}`);
// journeys
const stageKey = new Set();
const cid = (ref) => (resolveCap(ref) || { id: 'UNRESOLVED:' + ref }).id;
data.stages.forEach((s) => { if (refProblem(s.capability)) E(`data/stages.json: capability ${refProblem(s.capability)}`); const k = cid(s.capability) + '|' + s.stage; if (stageKey.has(k)) E(`data/stages.json: duplicate stage "${s.stage}" for "${s.capability}"`); stageKey.add(k); });
const personas = [...new Set(data.persona_scores.map((r) => r.persona))];
const psKey = new Set();
data.persona_scores.forEach((r) => { if (!stageKey.has(cid(r.capability) + '|' + r.stage)) E(`data/persona_scores.json: no stage "${r.stage}" for "${r.capability}" in data/stages.json`); const k = cid(r.capability) + '|' + r.persona + '|' + r.stage; if (psKey.has(k)) E(`data/persona_scores.json: duplicate row ${k}`); psKey.add(k); });
const capsWithStages = [...new Set(data.stages.map((s) => cid(s.capability)))];
capsWithStages.forEach((id) => data.stages.filter((s) => cid(s.capability) === id).forEach((s) => personas.forEach((p) => { if (!psKey.has(id + '|' + p + '|' + s.stage)) E(`data/persona_scores.json: missing score for ${s.capability} / ${p} / ${s.stage}`); })));
const issueIds = new Set();
data.issues.forEach((q) => {
  if (!stageKey.has(cid(q.capability) + '|' + q.stage)) E(`data/issues.json: ${q.id} uses stage "${q.stage}" which is not defined for "${q.capability}"`);
  if (issueIds.has(q.id)) E(`data/issues.json: duplicate id ${q.id}`); issueIds.add(q.id);
  if (q.jira_status === 'Raised' && !q.ticket) E(`data/issues.json: ${q.id} is Raised but has no ticket`);
  if (q.jira_status !== 'Raised' && q.ticket) Wn(`data/issues.json: ${q.id} has a ticket but status is "${q.jira_status}"`);
  (q.personas || '').split('; ').filter(Boolean).forEach((p) => { if (personas.length && !personas.includes(p)) Wn(`data/issues.json: ${q.id} names persona "${p}" with no scores`); });
  if (q.path === 'B' && !q.signal) Wn(`data/issues.json: ${q.id} is Path B with no signal (for example Iframe or Deprecated design system)`);
  if (q.screenshot) { if (!fs.existsSync(q.screenshot)) E(`data/issues.json: ${q.id} screenshot not found at ${q.screenshot}`); if (!(q.box_w > 0 && q.box_h > 0)) Wn(`data/issues.json: ${q.id} has a screenshot but no box_x/box_y/box_w/box_h (percent of the image)`); }
  if (q.jira_status === 'Not valid' && q.lift) Wn(`data/issues.json: ${q.id} is Not valid but has lift ${q.lift}; lift is ignored for invalid issues`);
});
capsWithStages.forEach((id) => { const cap = caps.find((c) => c.id === id); if (!cap) return; const n = data.issues.filter((q) => cid(q.capability) === id && q.jira_status !== 'Not valid').length; if (n > cap.blockers + cap.majors) Wn(`${cap.name}: ${n} valid issues listed, but wheel.json says it has ${cap.blockers + cap.majors} blockers and majors`); });
// report
const real = data.wheel.filter((r) => r.real === 1).length;
console.log(`Checked ${Object.keys(SPEC).length} files. Capabilities with journeys: ${capsWithStages.length}. Wheel rows marked real: ${real} of ${data.wheel.length}.`);
warns.forEach((m) => console.log('  warn  ' + m));
errors.forEach((m) => console.log('  ERROR ' + m));
console.log(errors.length ? `\n${errors.length} error(s), ${warns.length} warning(s).` : `\nOK. ${warns.length} warning(s).`);
process.exit(errors.length ? 1 : 0);
