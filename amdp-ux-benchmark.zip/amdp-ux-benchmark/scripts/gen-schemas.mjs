// Writes JSON Schemas so VS Code underlines bad rows in data/*.json as you type: npm run schemas
import fs from 'node:fs';
import { SPEC } from './spec.mjs';
fs.mkdirSync('schema/schemas', { recursive: true });
for (const [name, spec] of Object.entries(SPEC)) {
  const props = {}, required = [];
  for (const [col, c] of Object.entries(spec.cols)) {
    let p;
    if (c.t === 'str') p = { type: 'string' };
    else if (c.t === 'num') p = { type: 'number', ...(c.min != null ? { minimum: c.min } : {}), ...(c.max != null ? { maximum: c.max } : {}) };
    else if (c.t === 'numblank') p = { anyOf: [{ const: '' }, { type: 'number', ...(c.min != null ? { minimum: c.min } : {}), ...(c.max != null ? { maximum: c.max } : {}) }] };
    else if (c.t === 'flag') p = { enum: [0, 1] };
    else if (c.t === 'enum') p = { enum: c.values };
    props[col] = p;
    if (c.req) required.push(col);
  }
  const schema = { $schema: 'http://json-schema.org/draft-07/schema#', title: name, type: 'array', items: { type: 'object', required, properties: props, additionalProperties: false } };
  fs.writeFileSync(`schema/schemas/${name}.schema.json`, JSON.stringify(schema, null, 2) + '\n');
  console.log(`schema/schemas/${name}.schema.json`);
}
