// Export the JSON data to data/csv/*.csv for editing in a spreadsheet: npm run json2csv
import fs from 'node:fs';
import { SPEC } from './spec.mjs';
import { toCSV } from './csv.mjs';
fs.mkdirSync('data/csv', { recursive: true });
for (const [name, spec] of Object.entries(SPEC)) {
  const file = `data/${name}.json`;
  if (!fs.existsSync(file)) continue;
  const rows = JSON.parse(fs.readFileSync(file, 'utf8'));
  fs.writeFileSync(`data/csv/${name}.csv`, toCSV(Object.keys(spec.cols), rows));
  console.log(`data/csv/${name}.csv  ${rows.length} rows`);
}
