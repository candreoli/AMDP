// Single source of truth for the data contract. validate, csv<->json and the JSON Schemas all read this.
const S = (req = false, extra = {}) => ({ t: 'str', req, ...extra });
const NUM = (req = false, min, max, extra = {}) => ({ t: 'num', req, min, max, ...extra });
const BLANKNUM = (min, max) => ({ t: 'numblank', req: false, min, max });
const FLAG = (req = true) => ({ t: 'flag', req });
const ENUM = (values, req = true) => ({ t: 'enum', req, values });

export const SPEC = {
  portfolio: {
    cols: { key: S(true), value: NUM(true), label: S() },
    keys: ['score', 'confidence', 'blockers', 'majors', 'raised', 'screens', 'products', 'visual', 'ux', 'a11y', 'responsive', 'conformance'],
  },
  products: {
    cols: { name: S(true), score: NUM(true, 1, 5), screens: NUM(true, 0), of_total: BLANKNUM(0), cap: S() },
  },
  wheel: {
    cols: {
      id: S(true), name: S(true), type: ENUM(['cap', 'ring']), domain: S(), ord: BLANKNUM(0),
      score: NUM(true, 1, 5), visual: NUM(true, 1, 5), ux: NUM(true, 1, 5), a11y: NUM(true, 1, 5), responsive: NUM(true, 1, 5), conformance: NUM(true, 1, 5),
      confidence: NUM(true, 0, 100), blockers: NUM(true, 0), majors: NUM(true, 0), real: FLAG(),
    },
  },
  stages: {
    cols: { capability: S(true), stage: S(true), full: S(), screen: S(), layout: ENUM(['gallery', 'builder', 'dialog'], false), pain: S(), seam: FLAG(false) },
  },
  persona_scores: {
    cols: { capability: S(true), persona: S(true), stage: S(true), score: NUM(true, 1, 5) },
  },
  issues: {
    cols: {
      capability: S(true), id: S(true), stage: S(true), severity: ENUM(['Blocker', 'Major']),
      dimension: ENUM(['Visual', 'UX', 'A11y', 'Responsive', 'Conformance']), title: S(true), region: S(),
      personas: S(false), crawl: FLAG(), diagnostics: FLAG(), people: FLAG(),
      jira_status: ENUM(['Raised', 'Not raised', 'Not valid']), ticket: S(), effort: ENUM(['S', 'M', 'L']),
      lever: S(true), quadrant: ENUM(['Quick win', 'Big bet', 'Fix in place']), lift: NUM(true, 0, 1),
      path: ENUM(['A', 'B']), signal: S(), finding: S(true), fix: S(true), quote: S(),
      screenshot: S(), box_x: BLANKNUM(0, 100), box_y: BLANKNUM(0, 100), box_w: BLANKNUM(0, 100), box_h: BLANKNUM(0, 100),
    },
  },
  confidence_parts: {
    optional: true,
    cols: { part: S(true), points: NUM(true, 0), max: NUM(true, 1), to_lift: S() },
  },
};

export function coerce(spec, col, raw) {
  const c = spec.cols[col];
  if (!c) return raw;
  if (raw === '' || raw == null) return c.t === 'num' || c.t === 'flag' ? (c.t === 'flag' ? 0 : '') : '';
  if (c.t === 'num' || c.t === 'numblank') { const n = Number(raw); return Number.isNaN(n) ? raw : n; }
  if (c.t === 'flag') { const n = Number(raw); return Number.isNaN(n) ? raw : n; }
  return String(raw);
}
