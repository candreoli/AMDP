(function(){
'use strict';
var CFG=window.APP_CONFIG||{};
var TARGET=CFG.target||4;
var DIMS=[['visual','Visual'],['ux','UX'],['a11y','A11y'],['responsive','Responsive'],['conformance','Conformance']];
var BK=[['#5DCAA5','#04342C','Leading'],['#9FE1CB','#085041','Strong'],['#D3D1C7','#444441','Adequate'],['#FAC775','#633806','Needs work'],['#F5C4B3','#712B13','Critical']];
var CK=[['#534AB7','#EEEDFE','High'],['#7F77DD','#26215C','Good'],['#AFA9EC','#26215C','Moderate'],['#CECBF6','#3C3489','Low'],['#EEEDFE','#3C3489','Very low']];
var SENT=[['Frustrated','#F5C4B3','#712B13'],['Uneasy','#FAC775','#633806'],['Neutral','#D3D1C7','#444441'],['Positive','#9FE1CB','#085041']];
var LINES={'Data':['Data'],'Knowledge':['Knowledge'],'Generative AI':['Generative','AI'],'Agentic AI':['Agentic','AI'],'Traditional AI & Analytics':['Trad.','AI']};
var IDS=Object.keys(CFG.datasets||{});
var ALL='All personas';
var CX=250,CY=250;
var sel='p',tab=0,per=ALL,stg=-1,iss=null,colorBy='score',hov=null,M=null;
function rd(v){return Math.round(v*10)/10;}
function mean(a){return a.length?a.reduce(function(x,y){return x+y;},0)/a.length:0;}
function bk(v){v=Math.round(v*10)/10;return v<2.5?BK[4]:v<3?BK[3]:v<3.5?BK[2]:v<4?BK[1]:BK[0];}
function ck(v){return v>=80?CK[0]:v>=70?CK[1]:v>=60?CK[2]:v>=50?CK[3]:CK[4];}
function sentOf(v){return v<2.6?0:v<3?1:v<3.4?2:3;}
function f(v){return v==null||v===''?'–':Number(v).toFixed(1);}
function num(v){return Number(v).toLocaleString('en-US');}
function esc(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;');}
function N(ds,field,where,text){return esc(text);}
function nv(n,fld,text){return esc(text);}
function pillS(v,inner){var b=bk(v);return '<span class="wx-pill" style="background:'+b[0]+';color:'+b[1]+'">'+inner+'</span>';}
function npill(n,fld){var v=fld==='score'?n.s:n.d[DIMS.map(function(d){return d[0];}).indexOf(fld)];return pillS(v,f(v));}
function cpill(n){var b=ck(n.cf);return '<span class="wx-pill" style="background:'+b[0]+';color:'+b[1]+'">'+n.cf+'%</span>';}
function tag(real){return real?'<span class="wx-tag" style="background:#9FE1CB;color:#085041">Real data</span>':'<span class="wx-tag" style="background:var(--wx-soft);color:var(--color-fg-muted)">Sample data</span>';}
function sevT(s){return s==='Blocker'?'<span class="wx-tag" style="background:#F5C4B3;color:#712B13;font-weight:500">Blocker</span>':'<span class="wx-tag" style="background:#FAC775;color:#633806;font-weight:500">Major</span>';}
function jiraT(q){return q.jira_status==='Not valid'?'<span class="wx-tag" style="background:#D3D1C7;color:#444441">Not valid</span>':q.jira_status==='Raised'?'<span class="wx-tag" style="background:#9FE1CB;color:#085041">Raised '+esc(q.ticket)+'</span>':'<span class="wx-tag" style="background:#FAC775;color:#633806">Not raised</span>';}
function dots(q){var N3=['Crawl','Diagnostics','People'];return [q.crawl,q.diagnostics,q.people].map(function(v,i){return '<span class="wx-cd" title="'+N3[i]+'" style="'+(+v?'background:#7F77DD':'border:1px dashed #888780')+'"></span>';}).join('');}
function build(D){
var m={port:{},nodes:{},caps:[],doms:[],rings:[],prod:D.products||[],parts:D.confidence_parts||[],byCap:{},personas:[],firstWorked:null};
D.portfolio.forEach(function(r){m.port[r.key]=Number(r.value);});
D.wheel.forEach(function(r){var n={id:String(r.id),name:r.name,type:r.type,domain:r.domain||'',ord:r.ord===''?0:Number(r.ord),s:Number(r.score),d:[+r.visual,+r.ux,+r.a11y,+r.responsive,+r.conformance],cf:+r.confidence,crit:+r.blockers,maj:+r.majors,real:+r.real===1};m.nodes[n.id]=n;if(n.type==='cap')m.caps.push(n);else if(n.type==='ring')m.rings.push(n);});
m.caps.sort(function(a,b){return a.ord-b.ord;});
var step=270/Math.max(1,m.caps.length);
m.caps.forEach(function(n,i){n.a0=270+i*step;n.a1=n.a0+step;});
var names=[];m.caps.forEach(function(c){if(names.indexOf(c.domain)<0)names.push(c.domain);});
names.forEach(function(nm,i){var ks=m.caps.filter(function(c){return c.domain===nm;}),id='dom'+i;
var d={id:id,name:nm,type:'domain',kids:ks,real:false,a0:ks[0].a0,a1:ks[ks.length-1].a1};
d.s=rd(mean(ks.map(function(k){return k.s;})));d.d=[0,1,2,3,4].map(function(j){return rd(mean(ks.map(function(k){return k.d[j];})));});d.cf=Math.round(mean(ks.map(function(k){return k.cf;})));
d.crit=ks.reduce(function(a,k){return a+k.crit;},0);d.maj=ks.reduce(function(a,k){return a+k.maj;},0);ks.forEach(function(k){k.dom=id;});m.doms.push(d);m.nodes[id]=d;});
m.nodes.p={id:'p',name:'Platform',type:'platform',s:m.port.score,d:[m.port.visual,m.port.ux,m.port.a11y,m.port.responsive,m.port.conformance],cf:m.port.confidence,crit:m.port.blockers,maj:m.port.majors,real:true};
(D.persona_scores||[]).forEach(function(r){if(m.personas.indexOf(r.persona)<0)m.personas.push(r.persona);});
function resolve(ref){var n=m.nodes[String(ref)];if(n&&n.type==='cap')return n;var L=m.caps.filter(function(c){return c.name===ref;});return L.length===1?L[0]:null;}
var capNames=[];(D.stages||[]).forEach(function(r){if(capNames.indexOf(r.capability)<0)capNames.push(r.capability);});
capNames.forEach(function(cn){var node=resolve(cn);if(!node)return;
var rows=D.issues.filter(function(r){return resolve(r.capability)===node;}),cnt={};
var isr=rows.map(function(r,i){var q={};Object.keys(r).forEach(function(k){q[k]=r[k];});q.evidence=(+r.crawl)+(+r.diagnostics)+(+r.people);q.confidence=Math.round(q.evidence/3*100);q.lift=Number(r.lift)||0;q.num=r.num?+r.num:i+1;q.valid=r.jira_status!=='Not valid';return q;});
var stages=D.stages.filter(function(r){return resolve(r.capability)===node;}).map(function(r){var L=isr.filter(function(q){return q.stage===r.stage;}),V=L.filter(function(q){return q.valid;});
return {stage:r.stage,full:r.full||r.stage,screen:r.screen||'',layout:r.layout||'builder',pain:r.pain||'',seam:+r.seam||0,issues:V.length,confidence:L.length?Math.round(mean(L.map(function(q){return q.evidence/3;}))*100):null,lift:rd(V.reduce(function(a,q){return a+q.lift;},0))};});
var ps={};m.personas.forEach(function(p){ps[p]={};});
D.persona_scores.filter(function(r){return resolve(r.capability)===node;}).forEach(function(r){(ps[r.persona]=ps[r.persona]||{})[r.stage]=Number(r.score);});
ps[ALL]={};stages.forEach(function(st){var vals=m.personas.map(function(p){return ps[p][st.stage];}).filter(function(v){return v!=null;});ps[ALL][st.stage]=vals.length?rd(mean(vals)):null;});
var V=isr.filter(function(q){return q.valid;}),order=['Quick win','Big bet','Fix in place'],levs=[];
V.forEach(function(q){var e=levs.filter(function(l){return l.lever===q.lever;})[0];if(!e){e={lever:q.lever,quadrant:q.quadrant,issues:0,lift:0};levs.push(e);}e.issues++;e.lift=rd(e.lift+q.lift);});
levs.sort(function(a,b){return order.indexOf(a.quadrant)-order.indexOf(b.quadrant);});
var cum=node.s,lev=[{lever:'Today',quadrant:'',issues:0,lift:0,cumulative:cum}];levs.forEach(function(l){cum=rd(cum+l.lift);lev.push({lever:l.lever,quadrant:l.quadrant,issues:l.issues,lift:l.lift,cumulative:cum});});
var A=V.filter(function(q){return q.path==='A';}),B=V.filter(function(q){return q.path==='B';});
var sum={issues_total:isr.length,jira_raised:V.filter(function(q){return q.jira_status==='Raised';}).length,jira_new:V.filter(function(q){return q.jira_status==='Not raised';}).length,jira_invalid:isr.length-V.length,path_a:A.length,path_b:B.length,path_a_small:A.filter(function(q){return q.effort==='S';}).length,path_a_medium:A.filter(function(q){return q.effort==='M';}).length,path_a_large:A.filter(function(q){return q.effort==='L';}).length,agent_ready:A.filter(function(q){return q.effort==='S';}).length};
m.byCap[node.id]={node:node,stages:stages,iss:isr,ps:ps,lev:lev,sum:sum,B:B};node.hasData=true;if(!m.firstWorked)m.firstWorked=node;});
m.prod.forEach(function(p){p.score=Number(p.score);p.screens=Number(p.screens);p.of=p.of_total===''||p.of_total==null?null:Number(p.of_total);p.capNode=p.cap?resolve(p.cap):null;});
return m;}
function C(){var n=M.nodes[sel];return n&&n.type==='cap'?M.byCap[n.id]||null:null;}
function PS(p,s){var c=C();if(!c)return {s:0,after:null};var v=(c.ps[p]||{})[s];if(v==null)v=c.ps[ALL][s];var st=c.stages.filter(function(x){return x.stage===s;})[0];return {s:v,after:v==null?null:Math.min(4.6,rd(v+(st?st.lift:0)))};}
function jAvg(p){var c=C();return rd(mean(c.stages.map(function(s){return PS(p,s.stage).s;}).filter(function(v){return v!=null;})));}
function val(n){return colorBy==='confidence'?n.cf:colorBy==='score'?n.s:n.d[DIMS.map(function(d){return d[0];}).indexOf(colorBy)];}
function col(n){return colorBy==='confidence'?ck(n.cf):bk(val(n));}
function lab(n){return colorBy==='confidence'?n.cf+'%':f(val(n));}
function drf(n){return !(n.id==='p'||(colorBy==='score'&&n.real));}
function pol(r,a){var t=a*Math.PI/180;return[CX+r*Math.sin(t),CY-r*Math.cos(t)];}
function pp(p){return p[0].toFixed(1)+','+p[1].toFixed(1);}
function seg(r0,r1,a0,a1){var lg=(a1-a0)>180?1:0;return 'M'+pp(pol(r1,a0))+' A'+r1+' '+r1+' 0 '+lg+' 1 '+pp(pol(r1,a1))+' L'+pp(pol(r0,a1))+' A'+r0+' '+r0+' 0 '+lg+' 0 '+pp(pol(r0,a0))+' Z';}
function wrap(s,mx){var w=s.split(' '),L=[],c='';w.forEach(function(x){if(c&&(c+' '+x).length>mx){L.push(c);c=x;}else{c=c?c+' '+x:x;}});if(c)L.push(c);return L;}
function tsp(L,st){var n=L.length,h='';L.forEach(function(l,i){h+='<tspan x="0" y="'+((i-(n-1)/2)*st).toFixed(1)+'">'+esc(l)+'</tspan>';});return h;}
function depth(){var n=M.nodes[sel];if(sel==='p')return 0;if(n.type!=='cap')return 1;if(iss)return 4;if(stg>=0)return 3;return 2;}
function act(k){if(sel==='p'||k==='p'||k===sel)return true;var s=M.nodes[sel];if(s.type==='domain')return M.nodes[k].dom===sel||k===sel;if(s.type==='cap')return k===s.dom;return false;}
function wheelSvg(w){
var els=[],labels=w>=520;
function add(k,h){els.push({k:k,h:h});}
function G(k,inner,name){var n=M.nodes[k];return '<g data-k="'+esc(k)+'" tabindex="0" role="button" aria-label="'+esc(name)+', '+lab(n)+'" style="cursor:pointer;outline:none" opacity="'+(act(k)?1:0.28)+'">'+inner+'</g>';}
function sk(k){return k===sel?'stroke="var(--color-fg)" stroke-width="2"':'stroke="var(--color-border-line)" stroke-width="0.6"';}
M.caps.forEach(function(n){var b=col(n),d=seg(146,244,n.a0,n.a1),a=(n.a0+n.a1)/2,p=pol(195,a),s=Math.sin(a*Math.PI/180),phi=s<0?a+90:a-90,L=wrap(n.name,15);
add(n.id,G(n.id,'<path d="'+d+'" fill="'+b[0]+'" '+sk(n.id)+'/>'+(drf(n)?'<path d="'+d+'" fill="url(#wxht)" stroke="none" style="pointer-events:none"/>':'')+(labels?'<text transform="translate('+p[0].toFixed(1)+' '+p[1].toFixed(1)+') rotate('+phi.toFixed(1)+')" text-anchor="middle" dominant-baseline="central" style="font-size:9.5px;fill:'+b[1]+';pointer-events:none">'+tsp(L,10.5)+'</text>':'')+'<title>'+esc(n.name)+': '+lab(n)+'</title>',n.name));});
M.doms.forEach(function(n){var b=col(n),a=(n.a0+n.a1)/2,p=pol(119,a),c=Math.cos(a*Math.PI/180),phi=c<0?a+180:a,d=seg(96,142,n.a0,n.a1),L=LINES[n.name]||wrap(n.name,10);
add(n.id,G(n.id,'<path d="'+d+'" fill="'+b[0]+'" '+sk(n.id)+'/><path d="'+d+'" fill="url(#wxht)" stroke="none" style="pointer-events:none"/><text transform="translate('+p[0].toFixed(1)+' '+p[1].toFixed(1)+') rotate('+phi.toFixed(1)+')" text-anchor="middle" dominant-baseline="central" style="font-size:13px;font-weight:500;fill:'+b[1]+';pointer-events:none">'+tsp(L,14)+'</text><title>'+esc(n.name)+': '+lab(n)+'</title>',n.name));});
var RS=[[44,66],[68,92]];
M.rings.slice(0,2).forEach(function(n,i){var r=RS[i],b=col(n),mid=(r[0]+r[1])/2,rp=mid-5,p0=pol(rp,-55),p1=pol(rp,55),pid='wxtp'+i;
var inner='<circle cx="'+CX+'" cy="'+CY+'" r="'+mid+'" fill="none" stroke="'+b[0]+'" stroke-width="'+(r[1]-r[0])+'"/><circle cx="'+CX+'" cy="'+CY+'" r="'+mid+'" fill="none" stroke="url(#wxht)" stroke-width="'+(r[1]-r[0])+'" style="pointer-events:none"/>';
inner+=n.id===sel?'<circle cx="'+CX+'" cy="'+CY+'" r="'+r[0]+'" fill="none" stroke="var(--color-fg)" stroke-width="2"/><circle cx="'+CX+'" cy="'+CY+'" r="'+r[1]+'" fill="none" stroke="var(--color-fg)" stroke-width="2"/>':'<circle cx="'+CX+'" cy="'+CY+'" r="'+r[0]+'" fill="none" stroke="var(--color-border-line)" stroke-width="0.6"/><circle cx="'+CX+'" cy="'+CY+'" r="'+r[1]+'" fill="none" stroke="var(--color-border-line)" stroke-width="0.6"/>';
inner+='<path id="'+pid+'" d="M'+pp(p0)+' A'+rp+' '+rp+' 0 0 1 '+pp(p1)+'" fill="none"/><text style="font-size:13px;font-weight:500;fill:'+b[1]+';pointer-events:none"><textPath href="#'+pid+'" startOffset="50%" text-anchor="middle">'+esc(n.name)+'</textPath></text><title>'+esc(n.name)+': '+lab(n)+'</title>';
add(n.id,G(n.id,inner,n.name));});
var P=M.nodes.p,pb=col(P);
add('p',G('p','<circle cx="'+CX+'" cy="'+CY+'" r="40" fill="'+pb[0]+'" '+sk('p')+'/><text x="'+CX+'" y="'+(CY-2)+'" text-anchor="middle" dominant-baseline="central" style="font-size:24px;font-weight:500;fill:'+pb[1]+';pointer-events:none">'+lab(P)+'</text><text x="'+CX+'" y="'+(CY+19)+'" text-anchor="middle" dominant-baseline="central" style="font-size:12px;fill:'+pb[1]+';pointer-events:none">'+(colorBy==='confidence'?'sure':'of 5')+'</text>','Platform'));
els.sort(function(x,y){return (x.k===sel?1:0)-(y.k===sel?1:0);});
var h='<defs><pattern id="wxht" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="6" stroke="rgba(0,0,0,0.2)" stroke-width="1.6"/></pattern></defs>';
els.forEach(function(e){h+=e.h;});
{M.caps.forEach(function(c){if(!c.hasData)return;var mp=pol(252,(c.a0+c.a1)/2);h+='<circle cx="'+mp[0].toFixed(1)+'" cy="'+mp[1].toFixed(1)+'" r="4.5" fill="#7F77DD" stroke="#EEEDFE" stroke-width="1" style="pointer-events:none"><title>Journey data loaded</title></circle>';});}
return '<svg width="100%" viewBox="0 0 500 500" role="group" aria-label="Product wheel colored by '+(colorBy==='score'?'overall score':colorBy)+'">'+h+'</svg>';}
function capHtml(k){var n=M.nodes[k],b=col(n);return '<div style="font-size:var(--cds-font-size-body);font-weight:500;line-height:1.25">'+esc(n.name)+'</div><div style="font-family:var(--font-anthropic-serif);font-size:var(--cds-font-size-title);line-height:1.15">'+(colorBy==='confidence'?n.cf+'%':f(val(n))+'<span class="wx-mut"> / 5</span>')+'</div><div style="margin-top:2px"><span class="wx-pill" style="background:'+b[0]+';color:'+b[1]+'">'+b[2]+'</span> <span class="wx-mut">'+(drf(n)?'Sample':'Real')+'</span></div>';}
function legHtml(){var S=colorBy==='confidence'?CK:BK,Lb=colorBy==='confidence'?['High 80+','Good 70+','Moderate 60+','Low 50+','Very low']:['Leading 4+','Strong 3.5+','Adequate 3+','Needs work 2.5+','Critical'];
return S.map(function(x,i){return '<span><span class="wx-sw" style="background:'+x[0]+'"></span>'+Lb[i]+'</span>';}).join('')+'<span><span class="wx-sw" style="background:repeating-linear-gradient(45deg,var(--wx-soft),var(--wx-soft) 2px,rgba(0,0,0,.25) 2px,rgba(0,0,0,.25) 3px)"></span>Sample data</span>';}
function chip(n){return '<div class="wx-ch go" data-go="'+esc(n.id)+'" tabindex="0"><span>'+esc(n.name)+(n.hasData?' <span class="wx-mut" style="color:var(--wx-acc)">Journey loaded</span>':'')+'</span>'+npill(n,'score')+'</div>';}
function row(l,v,key,n){return '<div class="wx-rw"><span>'+l+'</span><span class="wx-trk"><span style="width:'+(v/5*100)+'%;background:'+bk(v)[0]+'"></span></span><span style="text-align:right">'+f(v)+'</span></div>';}
function stack(n){var t=n.crit+n.maj||1;return '<div class="wx-b2"><span style="width:'+(n.crit/t*100)+'%;background:#E24B4A"></span><span style="flex:1;background:#EF9F27"></span></div><div class="wx-sm"><span style="color:var(--color-bad)">'+num(n.crit)+' blockers</span> · '+num(n.maj)+' majors</div>'+(n.id==='p'?'<div class="wx-mut">Out of '+num(M.port.raised)+' issues raised. Every issue has a recommended fix.</div>':'');}
function prodsFor(n){var L=M.prod.filter(function(p){if(n.id==='p')return true;if(n.type==='domain')return p.capNode&&p.capNode.dom===n.id;if(n.type==='cap')return p.capNode===n;return false;});
var h='<div class="wx-sec">'+(n.id==='p'?'Products ('+M.port.products+' scored, '+L.length+' shown)':'Products mapped here')+'</div>';
if(!L.length)return h+'<div class="wx-mut">No product is mapped here yet.</div>';
L.forEach(function(p){var sub=(p.of?p.screens+' of '+p.of:p.screens)+' screens';if(n.id==='p')sub+=p.capNode?' · '+esc(p.capNode.name):' · not mapped';
h+='<div class="wx-ch'+(p.capNode?' go':'')+'"'+(p.capNode?' data-go="'+esc(p.capNode.id)+'" tabindex="0"':'')+'><span>'+esc(p.name)+'<br><span class="wx-mut">'+sub+'</span></span>'+pillS(p.score,f(p.score))+'</div>';});
return h;}
function where(n){var h='<div class="wx-sec">Score by dimension, out of 5</div>';DIMS.forEach(function(d,j){h+=row(d[1],n.d[j],d[0],n);});
h+='<div class="wx-sec">Blockers and majors</div>'+stack(n)+prodsFor(n);
var L=n.id==='p'?M.doms:n.type==='domain'?n.kids:[];
if(L.length){L=L.slice().sort(function(a,b){return a.s-b.s;});h+='<div class="wx-sec">'+(n.id==='p'?'Domains':'Capabilities')+', lowest first</div>'+L.map(chip).join('');}return h;}
function trust(n){var P=M.nodes.p,h='<div class="wx-sec">Confidence in the scores</div><div style="display:flex;align-items:baseline;gap:8px"><span class="wx-kv">'+P.cf+'%</span>'+cpill(P)+'<span class="wx-mut">working estimate</span></div>';
h+='<div class="wx-b2" style="height:10px;margin:8px 0 6px;background:var(--wx-soft)"><span style="width:'+P.cf+'%;background:#7F77DD;border-radius:5px"></span></div>';
h+='<div class="wx-sec">What the score is made of</div>';
if(!M.parts.length)h+='<div class="wx-mut">Add data/confidence_parts.json to show how the confidence number is built.</div>';
M.parts.forEach(function(t){h+='<div class="wx-rw" style="grid-template-columns:9rem 1fr 3.6rem"><span>'+esc(t.part)+'</span><span class="wx-trk"><span style="width:'+(t.points/t.max*100)+'%;background:#7F77DD"></span></span><span style="text-align:right">'+t.points+'/'+t.max+'</span></div>'+(t.to_lift?'<div class="wx-mut" style="margin:0 0 6px">To lift: '+esc(String(t.to_lift).toLowerCase())+'</div>':'');});
h+='<div class="wx-sec">Three evaluators, one score</div>';
var ev=[['UX crawl agent','Agentic','Visual, UX, accessibility, responsiveness and design system conformance',true],['Diagnostics agent','Agentic','IA, journeys, task flows, heuristics, content, usability and service design',false],['People studies','Human','Interviews and usability tests from the research vault',false]];
ev.forEach(function(e){h+='<div class="wx-ch" style="display:block"><div style="display:flex;justify-content:space-between;gap:6px;font-weight:500"><span>'+e[0]+'</span><span class="wx-mut">'+e[1]+'</span></div><div class="wx-mut">'+e[2]+'</div><div style="margin-top:4px">'+(e[3]?tag(true)+' <span class="wx-mut">'+num(M.port.screens)+' screen reviews, '+M.port.products+' products</span>':'<span class="wx-mut">Evidence flags on each issue show where this evaluator agrees</span>')+'</div></div>';});
h+='<div class="wx-sec">Screen coverage in sampled products</div>';
var sm=M.prod.filter(function(p){return p.of;});if(!sm.length)h+='<div class="wx-mut">No product is sampled.</div>';
sm.forEach(function(p){var c=Math.round(p.screens/p.of*100);h+='<div class="wx-rw" style="grid-template-columns:9rem 1fr 7rem"><span>'+esc(p.name)+'</span><span class="wx-trk"><span style="width:'+c+'%;background:#EF9F27"></span></span><span class="wx-sm" style="text-align:right">'+p.screens+' of '+p.of+'</span></div>';});
return h+'<div class="wx-mut" style="margin-top:6px">Switch Color by to Confidence to see it on the wheel.</div>';}
function jrow(i,on){var c=C();function X(s){return 16+(s-1.5)/3*64;}var H=76,st=c.stages[i],rows=c.stages.map(function(x){return PS(per,x.stage).s;}),v=rows[i],x=X(v),b=bk(v),se=SENT[sentOf(v)];
var svg='<svg width="96" height="'+H+'" viewBox="0 0 96 '+H+'" style="display:block"><line x1="'+X(TARGET).toFixed(1)+'" y1="0" x2="'+X(TARGET).toFixed(1)+'" y2="'+H+'" stroke="var(--color-fg-muted)" stroke-width="0.6" stroke-dasharray="3 3"/>';
if(i>0)svg+='<line x1="'+((x+X(rows[i-1]))/2).toFixed(1)+'" y1="0" x2="'+x.toFixed(1)+'" y2="'+H/2+'" stroke="#888780" stroke-width="1.5"/>';
if(i<rows.length-1)svg+='<line x1="'+x.toFixed(1)+'" y1="'+H/2+'" x2="'+((x+X(rows[i+1]))/2).toFixed(1)+'" y2="'+H+'" stroke="#888780" stroke-width="1.5"/>';
svg+='<circle cx="'+x.toFixed(1)+'" cy="'+H/2+'" r="13" fill="'+b[0]+'" stroke="'+b[1]+'" stroke-width="0.5"/><text x="'+x.toFixed(1)+'" y="'+(H/2+4)+'" text-anchor="middle" style="font-size:12px;font-weight:500;fill:'+b[1]+'">'+f(v)+'</text></svg>';
return '<div class="wx-jr'+(on?' on':'')+'" data-stg="'+i+'" tabindex="0" style="min-height:'+H+'px">'+svg+'<div style="padding:4px 0"><div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap"><span style="font-weight:500">'+esc(st.stage)+'</span><span class="wx-tag" style="background:'+se[1]+';color:'+se[2]+'">'+se[0]+'</span>'+(st.seam?'<span class="wx-tag" style="background:var(--wx-accbg)">Seam</span>':'')+'</div><div class="wx-sm" style="color:var(--color-fg-muted);margin-top:2px">'+esc(st.pain)+'</div><div class="wx-mut">'+st.issues+' blockers and majors</div></div></div>';}
function journey(){var c=C(),rows=c.stages.map(function(x){return PS(per,x.stage).s;}),low=0;rows.forEach(function(v,i){if(v<rows[low])low=i;});var cn=[0,0,0,0];rows.forEach(function(v){cn[sentOf(v)]++;});
var h='<div class="wx-sec">Persona</div><div style="display:flex;flex-wrap:wrap;gap:4px">'+[ALL].concat(M.personas).map(function(p){return '<button class="wx-pc'+(per===p?' on':'')+'" data-per="'+esc(p)+'">'+esc(p)+'</button>';}).join('')+'</div>';
h+='<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:10px 0 6px"><div class="wx-take2" style="margin:0"><div class="wx-mut">Journey score</div><div class="wx-kv" style="font-size:var(--cds-font-size-heading)">'+f(jAvg(per))+'</div></div><div class="wx-take2" style="margin:0"><div class="wx-mut">Lowest stage</div><div style="font-weight:500">'+esc(c.stages[low].stage)+' · '+f(rows[low])+'</div></div></div>';
h+='<div class="wx-b2" style="height:8px">'+cn.map(function(k,i){return k?'<span style="flex:'+k+';background:'+SENT[i][1]+'"></span>':'';}).join('')+'</div><div class="wx-mut">Sentiment by stage: '+SENT.map(function(s){return s[0].toLowerCase();}).join(' · ')+'</div>';
h+='<div class="wx-sec">Journey by stage. Dashed line marks the '+f(TARGET)+' target. Click a stage.</div>';c.stages.forEach(function(s,i){h+=jrow(i,false);});return h;}
function fixv(){var c=C(),S=c.sum,h='<div class="wx-sec">Jira validation, '+S.issues_total+' issues</div><div class="wx-b2"><span style="flex:'+S.jira_raised+';background:#5DCAA5"></span><span style="flex:'+S.jira_new+';background:#EF9F27"></span><span style="flex:'+S.jira_invalid+';background:#B4B2A9"></span></div><div class="wx-mut">'+S.jira_raised+' already raised · '+S.jira_new+' not raised yet · '+S.jira_invalid+' not valid</div>';
var sig=c.B.map(function(q){return (q.signal||q.title).toLowerCase();}).filter(function(v,i,a){return a.indexOf(v)===i;}).join(', ');
h+='<div class="wx-sec">Fix current or start again</div><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px"><div class="wx-take2" style="margin:0;background:#9FE1CB;color:#085041"><div>Path A: fix current</div><div class="wx-kv" style="font-size:var(--cds-font-size-heading);color:#04342C">'+S.path_a+'</div><div>'+S.path_a_small+' small, '+S.path_a_medium+' medium, '+S.path_a_large+' large</div></div><div class="wx-take2" style="margin:0;background:#F5C4B3;color:#712B13"><div>Path B: start again</div><div class="wx-kv" style="font-size:var(--cds-font-size-heading);color:#4A1B0C">'+S.path_b+'</div><div>'+esc(sig||'none')+'</div></div></div>';
h+='<div class="wx-sec">Path to green ('+f(TARGET)+'), if every issue in a lever is fixed</div>';
c.lev.forEach(function(l,i){var v=Number(l.cumulative),b=bk(v),pos=Math.max(0,Math.min(97,(v-2.5)/2.5*100));
h+='<div style="display:grid;grid-template-columns:1fr 110px 2.6rem;gap:8px;align-items:center;padding:3px 0"><span>'+esc(l.lever)+(i?'<br><span class="wx-mut">'+esc(l.quadrant)+' · '+l.issues+' issues · +'+f(l.lift)+'</span>':'')+'</span><span style="position:relative;display:block;height:8px;border-radius:4px;background:linear-gradient(90deg,#FAC775 0 20%,#D3D1C7 20% 40%,#9FE1CB 40% 60%,#5DCAA5 60% 100%)"><span style="position:absolute;top:-3px;left:calc('+pos+'% - 2px);width:4px;height:14px;background:#534AB7;border-radius:2px"></span></span><span style="text-align:right">'+pillS(v,f(v))+'</span></div>';});
h+='<div class="wx-mut">Scale runs from 2.5 to 5.0. Lift per issue comes from the lift column in data/issues.json.</div>';
h+='<div class="wx-take2"><span style="color:var(--color-fg)">Into the UX loop:</span> '+S.agent_ready+' small fixes on Path A are agent-ready. The '+S.path_b+' rebuilds need team design and sign-off, and the exit gate needs an outcome check, not just a score of '+f(TARGET)+'.</div>';return h;}
var REG={cards:[72,50,224,106],canvas:[50,20,150,96],palette:[0,20,50,140],config:[200,20,100,96],console:[50,116,250,44],modal:[64,34,172,96]};
function wf(q,lay){var G='#D3D1C7',L='#E8E6DD',s='<svg width="100%" viewBox="0 0 300 160" role="img" aria-label="Annotated screen sketch"><rect x="0.5" y="0.5" width="299" height="159" rx="6" fill="#F1EFE8" stroke="#B4B2A9" stroke-width="0.6"/><rect x="1" y="1" width="298" height="19" rx="5" fill="'+G+'"/><rect x="8" y="7" width="50" height="6" rx="2" fill="#B4B2A9"/>';
if(lay==='gallery'){s+='<rect x="8" y="28" width="58" height="124" rx="3" fill="'+L+'"/><rect x="74" y="28" width="218" height="16" rx="3" fill="'+L+'"/>';for(var i=0;i<3;i++)for(var j=0;j<2;j++)s+='<rect x="'+(74+i*74)+'" y="'+(52+j*54)+'" width="66" height="46" rx="3" fill="#CECBF6"/><rect x="'+(80+i*74)+'" y="'+(58+j*54)+'" width="30" height="5" rx="2" fill="#7F77DD"/>';}
else{s+='<rect x="2" y="22" width="46" height="136" fill="'+L+'"/><rect x="8" y="30" width="34" height="12" rx="2" fill="#CECBF6"/><rect x="8" y="48" width="34" height="12" rx="2" fill="#CECBF6"/><rect x="8" y="66" width="34" height="12" rx="2" fill="#CECBF6"/><line x1="106" y1="46" x2="124" y2="74" stroke="#888780" stroke-width="1.5"/><line x1="168" y1="74" x2="176" y2="96" stroke="#888780" stroke-width="1.5"/><rect x="62" y="36" width="44" height="20" rx="4" fill="#9FE1CB"/><rect x="124" y="64" width="44" height="20" rx="4" fill="#9FE1CB"/><rect x="150" y="92" width="44" height="18" rx="4" fill="#9FE1CB"/><rect x="200" y="20" width="100" height="96" fill="'+L+'"/><rect x="208" y="30" width="84" height="12" rx="2" fill="#D3D1C7"/><rect x="208" y="50" width="84" height="12" rx="2" fill="#D3D1C7"/><rect x="208" y="70" width="84" height="12" rx="2" fill="#D3D1C7"/><rect x="208" y="90" width="40" height="12" rx="2" fill="#7F77DD"/><rect x="50" y="116" width="250" height="44" fill="#E8E6DD"/><rect x="58" y="124" width="150" height="5" rx="2" fill="#B4B2A9"/><rect x="58" y="136" width="190" height="5" rx="2" fill="#B4B2A9"/>';
if(lay==='dialog')s+='<rect x="1" y="21" width="298" height="138" fill="#000" fill-opacity="0.18"/><rect x="64" y="34" width="172" height="96" rx="6" fill="#FFFFFF" stroke="#B4B2A9" stroke-width="0.6"/><rect x="74" y="44" width="70" height="7" rx="2" fill="#888780"/><rect x="74" y="62" width="152" height="12" rx="2" fill="#E8E6DD"/><rect x="74" y="82" width="152" height="12" rx="2" fill="#E8E6DD"/><rect x="170" y="106" width="56" height="14" rx="3" fill="#7F77DD"/>';}
var r=REG[q.region]||REG.canvas;s+='<rect x="'+r[0]+'" y="'+r[1]+'" width="'+r[2]+'" height="'+r[3]+'" rx="4" fill="rgba(216,90,48,0.14)" stroke="#D85A30" stroke-width="1.5" stroke-dasharray="4 3"/><circle cx="'+(r[0]+12)+'" cy="'+(r[1]+12)+'" r="10" fill="#D85A30"/><text x="'+(r[0]+12)+'" y="'+(r[1]+16)+'" text-anchor="middle" style="font-size:11px;font-weight:500;fill:#fff">'+q.num+'</text></svg>';return s;}
function shot(q,lay){if(!q.screenshot)return wf(q,lay);var x=+q.box_x||0,y=+q.box_y||0,w=+q.box_w||0,h=+q.box_h||0;return '<div class="wx-shot"><img src="'+esc(q.screenshot)+'" alt="Screenshot of '+esc(q.title)+'">'+(w?'<div class="wx-box" style="left:'+x+'%;top:'+y+'%;width:'+w+'%;height:'+h+'%"></div><div class="wx-pin" style="left:calc('+x+'% - 6px);top:calc('+y+'% - 6px)">'+q.num+'</div>':'')+'</div>';}
function stageView(){var c=C(),st=c.stages[stg],list=c.iss.filter(function(q){return q.stage===st.stage;}),h='';
h+='<div class="wx-sec">Who feels it, score by persona. Click to focus.</div><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(11rem,1fr));gap:4px">'+M.personas.map(function(p){var v=PS(p,st.stage).s;return '<div class="wx-ch go'+(per===p?' sel':'')+'" data-per="'+esc(p)+'" tabindex="0" style="margin:0"><span>'+esc(p)+'</span>'+pillS(v,f(v))+'</div>';}).join('')+'</div>';
h+='<div class="wx-sec">What users hit</div><div>'+esc(st.pain)+(st.pain?'.':'')+(st.seam?' This stage is a hand-off between products.':'')+'</div>';
var qq=list.filter(function(q){return q.quote;})[0];if(qq)h+='<div class="wx-q">“'+esc(qq.quote)+'”<div class="wx-mut">From the research vault</div></div>';
h+='<div class="wx-sec">Issues at this stage, blockers and majors</div>';
if(!list.length)h+='<div class="wx-mut">No issues recorded for this stage.</div>';
list.forEach(function(q){var dimmed=per!==ALL&&String(q.personas).split('; ').indexOf(per)<0;h+='<div class="wx-ch go" data-iss="'+esc(q.id)+'" tabindex="0" style="display:block;'+(dimmed?'opacity:.45':'')+'"><div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">'+sevT(q.severity)+'<span style="font-weight:500">'+esc(q.title)+'</span></div><div class="wx-mut" style="margin-top:3px">'+esc(q.id)+' · '+esc(q.dimension)+' · '+jiraT(q)+' · '+dots(q)+'</div></div>';});
if(per!==ALL)h+='<div class="wx-mut">Faded issues do not affect '+esc(per)+'.</div>';
var r=PS(per,st.stage);h+='<div class="wx-sec">Fix this stage</div><div>Fixing the valid issues lifts this stage from '+f(r.s)+' to '+f(r.after==null?r.s:r.after)+'.</div>';return h;}
function issueView(){var c=C(),q=c.iss.filter(function(x){return x.id===iss;})[0],st=c.stages.filter(function(s){return s.stage===q.stage;})[0],N3=['UX crawl agent','Diagnostics agent','People studies'],ev=[+q.crawl,+q.diagnostics,+q.people],h='<div style="margin-top:8px;max-width:30rem">'+shot(q,st.layout)+'</div><div class="wx-mut">'+esc(st.screen)+'. The pin marks where it happens.</div>';
h+='<div class="wx-sec">What we found</div><div>'+esc(q.finding)+'</div>';
if(q.quote)h+='<div class="wx-q">“'+esc(q.quote)+'”<div class="wx-mut">From the research vault</div></div>';
h+='<div class="wx-sec">Evidence, '+q.evidence+' of 3 evaluators agree</div>'+ev.map(function(v,i){return '<div class="wx-sm"><span class="wx-cd" style="'+(v?'background:#7F77DD':'border:1px dashed #888780')+'"></span>'+N3[i]+' <span class="wx-mut">'+(v?'found it':'not yet')+'</span></div>';}).join('');
h+='<div class="wx-sec">Who it hurts</div><div style="display:flex;flex-wrap:wrap;gap:4px">'+String(q.personas).split('; ').filter(Boolean).map(function(p){return '<span class="wx-tag" style="background:var(--wx-soft)">'+esc(p)+'</span>';}).join('')+'</div>';
h+='<div class="wx-sec">Jira</div><div>'+jiraT(q)+' <span class="wx-mut">'+(q.jira_status==='Not raised'?'Valid and new. File it.':q.jira_status==='Not valid'?'The agent flagged it and the team ruled it out. Use it to tune the agent.':'Matches an open ticket.')+'</span></div>';
h+='<div class="wx-sec">Recommended fix</div><div>'+esc(q.fix)+'</div>';
if(q.valid){var A=q.path==='A';h+='<div style="display:flex;flex-wrap:wrap;gap:4px;margin-top:6px"><span class="wx-tag" style="background:var(--wx-soft)">Effort '+esc(q.effort)+'</span><span class="wx-tag" style="background:var(--wx-accbg)">'+esc(q.lever)+' · '+esc(q.quadrant)+'</span><span class="wx-tag" style="background:'+(A?'#9FE1CB':'#F5C4B3')+';color:'+(A?'#085041':'#712B13')+'">'+(A?'Path A: fix current':'Path B: start again')+'</span>'+(q.signal?'<span class="wx-tag" style="background:#FCEBEB;color:#791F1F">Signal: '+esc(q.signal)+'</span>':'')+'</div><div class="wx-mut" style="margin-top:4px">Estimated lift on the capability score: +'+f(q.lift)+'</div>';}
return h;}
var LAYERS=['Platform','Area','Capability','Stage','Issue'];
function crumbs(){var n=M.nodes[sel],c=[['P','Platform']];if(sel!=='p'){var dm=n.type==='cap'?M.nodes[n.dom]:n;c.push(['D:'+dm.id,dm.name]);if(n.type==='cap')c.push(['C',n.name]);}if(stg>=0)c.push(['S',C().stages[stg].stage]);if(iss)c.push(['I',iss]);
if(c.length===1)return 'Platform';return c.map(function(x,i){return i===c.length-1?'<span style="color:var(--color-fg)">'+esc(x[1])+'</span>':'<span data-nav="'+esc(x[0])+'" style="cursor:pointer;color:var(--wx-acc)">'+esc(x[1])+'</span>';}).join(' › ');}
function ask(d,n,tb){var pn=per===ALL?'all personas':per;
if(d===0)return tb===0?'Write the CIO narrative for where we are, using the benchmark scores':'Draft the methodology and confidence slide for the CIO';
if(d===1)return 'Write the where-we-are narrative for '+n.name+' using its weakest capabilities';
if(d===2)return tb===0?'Show pain points and research vault quotes for the '+n.name+' journey for '+pn+', starting where sentiment is lowest':'Turn the '+n.name+' fixes into a 2027 plan: what agents take, what the team rebuilds, and target scores';
if(d===3)return 'Draft the fix plan for the '+C().stages[stg].stage+' stage of the '+n.name+' journey';
return 'Draft the Jira ticket for '+iss+', or check the matching ticket against the finding';}
function panel(){var n=M.nodes[sel],d=depth(),c=C(),real=n.id==='p'||n.real,h='<div class="wx-strip">'+LAYERS.map(function(l,i){return '<div><i class="'+(i<=d?'on':'')+'"></i><span class="'+(i===d?'cur':'')+'">'+l+'</span></div>';}).join('')+'</div>',TB=null;
if(d===0)TB=['Where','Trust'];else if(d===2&&c)TB=['Journey','Fix'];
if(TB)h+='<div class="wx-tabs">'+TB.map(function(t,i){return '<button class="wx-tb'+(i===tab?' on':'')+'" data-t="'+i+'">'+t+'</button>';}).join('')+'</div>';
h+='<div class="wx-mut" style="margin-top:10px">'+crumbs()+'</div>';
var title,sub,right;
if(d<=2){title=esc(n.name);sub='<div style="margin-top:3px;display:flex;gap:4px;align-items:center">'+tag(real)+cpill(n)+'</div>';right='<div class="wx-kv">'+f(n.s)+'</div><span class="wx-mut">of 5</span>';}
else if(d===3){var st=c.stages[stg],v=PS(per,st.stage).s,se=SENT[sentOf(v)],cf=st.confidence==null?null:st.confidence;title=esc(st.full);sub='<div style="margin-top:3px;display:flex;gap:4px;align-items:center"><span class="wx-tag" style="background:'+se[1]+';color:'+se[2]+'">'+se[0]+'</span>'+(cf==null?'':'<span class="wx-pill" style="background:'+ck(cf)[0]+';color:'+ck(cf)[1]+'">'+cf+'%</span>')+'<span class="wx-mut">'+esc(per.toLowerCase())+'</span></div>';right='<div class="wx-kv">'+f(v)+'</div><span class="wx-mut">of 5</span>';}
else{var q=c.iss.filter(function(x){return x.id===iss;})[0];title=esc(q.title);sub='<div style="margin-top:3px;display:flex;gap:4px;align-items:center;flex-wrap:wrap">'+sevT(q.severity)+'<span class="wx-mut">'+esc(q.dimension)+'</span><span class="wx-pill" style="background:'+ck(q.confidence)[0]+';color:'+ck(q.confidence)[1]+'">'+q.confidence+'%</span></div>';right='<div class="wx-mut">'+esc(q.id)+'</div>';}
h+='<div style="display:flex;justify-content:space-between;gap:8px;align-items:flex-start"><div><div style="font-size:var(--cds-font-size-heading);font-weight:var(--cds-font-weight-medium)">'+title+'</div>'+sub+'</div><div style="text-align:right;flex:none">'+right+'</div></div>';
var showAsk=true;
if(d===0)h+=tab===0?where(n):trust(n);
else if(d===1)h+=where(n);
else if(d===2){if(!c){h+='<div class="wx-nodata">No journey data for this capability yet. Add rows for it to <code>data/stages.json</code>, <code>data/persona_scores.json</code> and <code>data/issues.json</code>, using the capability name exactly as it appears in <code>data/wheel.json</code>.'+(M.firstWorked?' <span data-go="'+esc(M.firstWorked.id)+'" style="cursor:pointer;text-decoration:underline">See '+esc(M.firstWorked.name)+', which has data.</span>':'')+'</div>'+where(n);showAsk=false;}else h+=tab===0?journey():fixv();}
else if(d===3)h+=stageView();
else h+=issueView();
if(showAsk)h+='<div class="wx-take2">Ask Claude: “'+esc(ask(d,n,tab))+'”</div>';
document.getElementById('wx-side').innerHTML=h;}
function skeleton(failed,msgs){var sk=failed?'<div class="wx-fail">Failed to load. '+esc((msgs||[]).join(' · '))+' Serve this folder over http (see README) rather than opening the file directly.</div>':'<div class="dash-skeleton" style="min-height:8rem"></div>';document.getElementById('wx-kpis').innerHTML='<div class="wx-card">'+sk+'</div>';document.getElementById('wx-wheel').innerHTML='<div style="min-height:20rem">'+(failed?'':sk)+'</div>';document.getElementById('wx-side').innerHTML=failed?'':sk;document.getElementById('wx-cap').innerHTML='';document.getElementById('wx-leg').innerHTML='';}
function kcard(l,v,s){return '<div class="wx-card"><div class="wx-kl">'+l+'</div><div class="wx-kv">'+v+'</div><div class="wx-ks">'+s+'</div></div>';}
function render(){
var D={},ok=true,bad=false,msgs=[];IDS.forEach(function(i){var d=dash.data(i);D[i]=d.data;if(d.status!=='ok')ok=false;if(d.status==='error'){bad=true;msgs.push(d.message);}});
if(!ok){skeleton(bad,msgs);return;}
var wasSel=sel;M=build(D);if(!M.nodes[sel])sel='p';if(wasSel!==sel){stg=-1;iss=null;}
if(per!==ALL&&M.personas.indexOf(per)<0)per=ALL;
var P=M.nodes.p;
document.getElementById('wx-title').textContent=CFG.title||'Benchmark';
document.getElementById('wx-take').innerHTML='The portfolio scores '+f(P.s)+' out of 5 across '+M.port.products+' products. Design system conformance is the weakest dimension at '+f(P.d[4])+', and confidence in the scores is '+P.cf+'%.';
document.getElementById('wx-kpis').innerHTML=kcard('Portfolio score',f(P.s)+'<span class="wx-ks"> / 5</span>','Across '+M.port.products+' products')+kcard('Confidence in scores',P.cf+'%','Working estimate')+kcard('Blockers',num(P.crit),'and '+num(P.maj)+' majors, from '+num(M.port.raised)+' issues raised')+kcard('Screen reviews',num(M.port.screens),'Agentic UX crawl');
var w=document.getElementById('wx-wheel').clientWidth||600;
document.getElementById('wx-wheel').innerHTML=wheelSvg(w);
document.getElementById('wx-cap').innerHTML=capHtml(hov&&M.nodes[hov]?hov:sel);
document.getElementById('wx-leg').innerHTML=legHtml();
panel();}
function select(k){sel=k;tab=0;stg=-1;iss=null;render();}
var root=document.getElementById('wx');
root.addEventListener('click',function(e){var t;
if((t=e.target.closest('[data-k]')))return select(t.getAttribute('data-k'));
if((t=e.target.closest('[data-go]')))return select(t.getAttribute('data-go'));
if((t=e.target.closest('[data-nav]'))){var x=t.getAttribute('data-nav');if(x==='P')return select('p');if(x.indexOf('D:')===0)return select(x.slice(2));if(x==='C'){stg=-1;iss=null;tab=0;}else if(x==='S'){iss=null;}return render();}
if((t=e.target.closest('[data-t]'))){tab=+t.getAttribute('data-t');return render();}
if((t=e.target.closest('[data-per]'))){per=t.getAttribute('data-per');return render();}
if((t=e.target.closest('[data-stg]'))){stg=+t.getAttribute('data-stg');iss=null;return render();}
if((t=e.target.closest('[data-iss]'))){iss=t.getAttribute('data-iss');var c=C();stg=c.stages.map(function(s){return s.stage;}).indexOf(c.iss.filter(function(q){return q.id===iss;})[0].stage);return render();}});
root.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){var t=e.target.closest('[data-k],[data-go],[data-stg],[data-iss],[data-per]');if(t&&t.tagName!=='BUTTON'){e.preventDefault();t.dispatchEvent(new MouseEvent('click',{bubbles:true}));}}});
var wheel=document.getElementById('wx-wheel');
wheel.addEventListener('mouseover',function(e){var t=e.target.closest('[data-k]');if(t&&M){hov=t.getAttribute('data-k');document.getElementById('wx-cap').innerHTML=capHtml(hov);}});
wheel.addEventListener('mouseleave',function(){if(M){hov=null;document.getElementById('wx-cap').innerHTML=capHtml(sel);}});
document.getElementById('wx-dim').addEventListener('change',function(e){colorBy=e.target.value;render();});
dash.onData(render);
})();
