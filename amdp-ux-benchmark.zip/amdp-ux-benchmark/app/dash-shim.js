/* Minimal stand-in for the hosted dashboard runtime: loads JSON files and calls the page when data or width changes. */
(function () {
  var CFG = window.APP_CONFIG, store = {}, status = {}, message = {}, subs = [];
  window.d3 = { format: function () { return function (v) { return Number(v).toLocaleString('en-US'); }; } };
  window.dash = {
    data: function (id) { return { status: status[id] || 'loading', data: store[id] || [], message: message[id] || '' }; },
    onData: function (fn) { subs.push(fn); fn(); }
  };
  function notify() { subs.forEach(function (fn) { try { fn(); } catch (e) { console.error(e); } }); }
  Object.keys(CFG.datasets).forEach(function (id) {
    status[id] = 'loading';
    fetch(CFG.datasets[id]).then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
      .then(function (j) { store[id] = Array.isArray(j) ? j : (j.rows || j.data || []); status[id] = 'ok'; notify(); })
      .catch(function (e) {
        if ((CFG.optional || []).indexOf(id) > -1) { store[id] = []; status[id] = 'ok'; }
        else { status[id] = 'error'; message[id] = CFG.datasets[id] + ': ' + e.message; }
        notify();
      });
  });
  var t; window.addEventListener('resize', function () { clearTimeout(t); t = setTimeout(notify, 120); });
})();
