/* App configuration. Point each dataset id at a file, mark optional ones, set your target score. */
window.APP_CONFIG = {
  title: 'AMDP experience benchmark',
  target: 4.0,                       // the green score used for the dashed line and path to green
  datasets: {
    portfolio:        'data/portfolio.json',
    products:         'data/products.json',
    wheel:            'data/wheel.json',
    stages:           'data/stages.json',
    persona_scores:   'data/persona_scores.json',
    issues:           'data/issues.json',
    confidence_parts: 'data/confidence_parts.json'
  },
  optional: ['confidence_parts']     // a missing optional file loads as an empty table
};
